# DataminerMyFirstScript

![WIP](./Images/wip.png)